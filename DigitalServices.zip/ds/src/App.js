import './assets/App.css';

function App() {
  return (
    <div className="App">
      <h2 className="">Welcome a</h2>
    </div>
  );
}

export default App;
